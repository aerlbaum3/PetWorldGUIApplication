﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StoreMangement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-BA909E15\SQLEXPRESS;Initial Catalog=StoreManagement;Integrated Security=True;TrustServerCertificate=True");
        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_login_Click(object sender, EventArgs e)
        {
            string username, user_password;
            username = userName_input.Text;
            user_password = password_input.Text;

            try
            {
                String query = "SELECT * FROM Users Where Username = '" + userName_input.Text + "' AND password = '" + password_input.Text + "'";
                SqlDataAdapter sd = new SqlDataAdapter(query, conn);

                DataTable dTable = new DataTable();
                sd.Fill(dTable);
                if(dTable.Rows.Count > 0)
                {
                    username = userName_input.Text;
                    user_password = password_input.Text;
                    MessageBox.Show("Success!");

                    PetStore petStore = new PetStore();
                    petStore.Show();
                    this.Hide();
                       
                }
                else
                {
                    MessageBox.Show("Invalid Login");
                }
            }
            catch
            {
                MessageBox.Show("Error");

            }
            finally
            {
                conn.Close(); 
            }



        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
