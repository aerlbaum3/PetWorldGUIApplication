﻿
namespace StoreMangement
{
    partial class PetStore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AddToCart = new System.Windows.Forms.DataGridView();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.storeManagementDataSet1 = new StoreMangement.StoreManagementDataSet1();
            this.itemsTableAdapter = new StoreMangement.StoreManagementDataSet1TableAdapters.ItemsTableAdapter();
            this.Purchase_button = new System.Windows.Forms.Button();
            this.Account_Info = new System.Windows.Forms.Button();
            this.Quantity_control = new System.Windows.Forms.NumericUpDown();
            this.itemNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.AddToCart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storeManagementDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Quantity_control)).BeginInit();
            this.SuspendLayout();
            // 
            // AddToCart
            // 
            this.AddToCart.AutoGenerateColumns = false;
            this.AddToCart.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.AddToCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AddToCart.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemNameDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.AddToCart.DataSource = this.itemsBindingSource;
            this.AddToCart.Location = new System.Drawing.Point(42, 44);
            this.AddToCart.Name = "AddToCart";
            this.AddToCart.RowHeadersWidth = 62;
            this.AddToCart.RowTemplate.Height = 28;
            this.AddToCart.Size = new System.Drawing.Size(321, 325);
            this.AddToCart.TabIndex = 0;
            this.AddToCart.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AddToCart_CellContentClick);
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.storeManagementDataSet1;
            // 
            // storeManagementDataSet1
            // 
            this.storeManagementDataSet1.DataSetName = "StoreManagementDataSet1";
            this.storeManagementDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // Purchase_button
            // 
            this.Purchase_button.Location = new System.Drawing.Point(402, 314);
            this.Purchase_button.Name = "Purchase_button";
            this.Purchase_button.Size = new System.Drawing.Size(104, 55);
            this.Purchase_button.TabIndex = 1;
            this.Purchase_button.Text = "Purchase";
            this.Purchase_button.UseVisualStyleBackColor = true;
            // 
            // Account_Info
            // 
            this.Account_Info.Location = new System.Drawing.Point(528, 314);
            this.Account_Info.Name = "Account_Info";
            this.Account_Info.Size = new System.Drawing.Size(125, 55);
            this.Account_Info.TabIndex = 2;
            this.Account_Info.Text = "View Account";
            this.Account_Info.UseVisualStyleBackColor = true;
            // 
            // Quantity_control
            // 
            this.Quantity_control.Location = new System.Drawing.Point(443, 67);
            this.Quantity_control.Name = "Quantity_control";
            this.Quantity_control.Size = new System.Drawing.Size(141, 26);
            this.Quantity_control.TabIndex = 3;
            // 
            // itemNameDataGridViewTextBoxColumn
            // 
            this.itemNameDataGridViewTextBoxColumn.DataPropertyName = "ItemName";
            this.itemNameDataGridViewTextBoxColumn.HeaderText = "ItemName";
            this.itemNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.itemNameDataGridViewTextBoxColumn.Name = "itemNameDataGridViewTextBoxColumn";
            this.itemNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 150;
            // 
            // PetStore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 408);
            this.Controls.Add(this.Quantity_control);
            this.Controls.Add(this.Account_Info);
            this.Controls.Add(this.Purchase_button);
            this.Controls.Add(this.AddToCart);
            this.Name = "PetStore";
            this.Text = "PetStore";
            this.Load += new System.EventHandler(this.PetStore_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AddToCart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storeManagementDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Quantity_control)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView AddToCart;
        private StoreManagementDataSet1 storeManagementDataSet1;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private StoreManagementDataSet1TableAdapters.ItemsTableAdapter itemsTableAdapter;
        private System.Windows.Forms.Button Purchase_button;
        private System.Windows.Forms.Button Account_Info;
        private System.Windows.Forms.NumericUpDown Quantity_control;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
    }
}