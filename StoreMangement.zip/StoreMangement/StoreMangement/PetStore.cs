﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StoreMangement
{
    public partial class PetStore : Form

    {
        private SqlConnection conn;
        private SqlDataAdapter dataAdapter;
        private DataTable itemsTable;
        private decimal totalPrice;
        public PetStore()
        {
            InitializeComponent(); 
            InitializeDatabase();
            LoadItems();

            // DataGridView settings
            AddToCart.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AddToCart.MultiSelect = false;

            // Event handlers
            AddToCart.CellContentClick += AddToCart_CellContentClick;
            Purchase_button.Click += ButtonPurchase_Click;

            // Call method to populate DataGridView
            PopulateDataGridView();
        }

        private void PopulateDataGridView()
        {
            try
            {
                conn.Open();
                string query = "SELECT ItemName,Price FROM Items";
                dataAdapter = new SqlDataAdapter(query, conn);
                itemsTable = new DataTable();
                dataAdapter.Fill(itemsTable);

                // Bind data to DataGridView
                AddToCart.DataSource = itemsTable;

                // Optional: Set DataPropertyName for each column
                //AddToCart.Columns["ItemName"].DataPropertyName = "ItemName";
                //AddToCart.Columns["Price"].DataPropertyName = "Price";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void PetStore_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'storeManagementDataSet1.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.storeManagementDataSet1.Items);

        }

       

        private void InitializeDatabase()
        {
            conn = new SqlConnection(@"Data Source=LAPTOP-BA909E15\SQLEXPRESS;Initial Catalog=StoreManagement;Integrated Security=True;TrustServerCertificate=True");

        }

        private void LoadItems()
        {
            try
            {
                conn.Open();
                string query = "SELECT ItemId, ItemName, Price FROM Items";
                dataAdapter = new SqlDataAdapter(query, conn);
                itemsTable = new DataTable();
                dataAdapter.Fill(itemsTable);

                AddToCart.DataSource = itemsTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void AddToCart_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = AddToCart.Rows[e.RowIndex];
                string itemName = Convert.ToString(selectedRow.Cells["ItemName"].Value);
                MessageBox.Show("XXX" + itemName);
                decimal price = Convert.ToDecimal(selectedRow.Cells["Price"].Value);

                // Display the price of the item in a pop-up message
                MessageBox.Show($"You clicked on {itemName}. Price: {price:C}");
            }
        }

        private void ButtonPurchase_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = AddToCart.CurrentRow;
            if (selectedRow != null)
            {
                string itemName = Convert.ToString(selectedRow.Cells["ItemName"].Value);
                decimal price = Convert.ToDecimal(selectedRow.Cells["Price"].Value);
                int quantity = (int)Quantity_control.Value;

                decimal totalItemPrice = price * quantity;

                // Display the purchase details in a pop-up message
                MessageBox.Show($"You have purchased {quantity} of {itemName} for {totalItemPrice:C}");

                // Optionally, update the total price label
                totalPrice += totalItemPrice;
              

                // Update the user's account balance in the database (if needed)
                // UpdateUserAccount(totalItemPrice);
            }
            else
            {
                MessageBox.Show("Please select an item to purchase.");
            }
        }

        // Optionally, add a method to update user account in database
        // private void UpdateUserAccount(decimal totalItemPrice) { ... }
    }

}

